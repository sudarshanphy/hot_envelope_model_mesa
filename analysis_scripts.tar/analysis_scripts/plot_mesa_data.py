import matplotlib.pyplot as plt
import mesa_reader as mr
import matplotlib
import numpy as np

# Set default font
rc = {"font.family" : "serif", "mathtext.fontset" : "stix"}
matplotlib.rcParams.update(rc)

# Read the history file.
ds = mr.MesaData('./history.data')

# Get the data from the history file. 
age = ds.data('star_age')
log_Lnuc = 10 ** ds.data('log_Lnuc')
log_other = 10 ** ds.data('cno')
log_he = 10 ** ds.data('tri_alfa')
max_burn_loc = ds.data('mass_loc_of_max_eps_nuc')

# Plot the data.
plt.figure(figsize=(12,12))
font_size = 20
plt.plot(age, max_burn_loc, linewidth = 2.0)
plt.xticks(fontsize = font_size)
plt.yticks(fontsize = font_size)
plt.xlim([1e-3,1e10])
plt.ylim([0.0,0.5])
plt.xscale("log")
#plt.figtext(0.7,0.9,"Age: %5.3e Yr"%(time), fontsize = font_size)
plt.xlabel("Time (Yr)", fontsize = font_size)
#plt.ylabel("L due to Triple alpha process "+r"$(L_{\bigodot})$", fontsize = font_size)
plt.ylabel("Mass location of max burning", fontsize = font_size)
plt.xticks(fontsize = font_size)
plt.yticks(fontsize = font_size)
plt.savefig("time_vs_max_burn_loc.png")
#plt.show()
