import matplotlib.pyplot as plt
import mesa_reader as mr
import matplotlib
import numpy as np

# Set default font
rc = {"font.family" : "serif", "mathtext.fontset" : "stix"}
matplotlib.rcParams.update(rc)

nfiles = 50 # Number of profile plots to create the movie
count = 1


# The present loop will generate multiple figures of temperature distribution.
while count <= nfiles:
    
    ds = mr.MesaData('./profile%d.data'%(count))i
    # Extracting various quntities from the prfile*.data fle
    time = float(ds.star_age)
    dens = ds.density
    temp = 10 ** ds.logT
    mass = ds.mass
    radius = ds.radius_cm
    eta = ds.eta
    specific_entropy = 10 ** ds.entropy
    he4 = ds.he4
    c12 = ds.c12
    o16 = ds.o16
    
    plt.figure(figsize=(12,12))
   
    font_size = 20
    #plt.plot(mass,he4, linewidth = 2, label = "he4")
    #plt.plot(mass, c12, linewidth = 2, label = "c12")
    #plt.plot(mass, o16, linewidth = 2, label = "o16")
    plt.plot(mass, temp, linewidth = 2)
    plt.xticks(fontsize = font_size)
    plt.yticks(fontsize = font_size)
    #plt.ylim([1e6,1e12])
    plt.yscale("log")
    plt.figtext(0.7,0.9,"Age: %5.3e Yr"%(time), fontsize = font_size)
    plt.xlabel("Mass ("+r'$M_{\bigodot}$'+")", fontsize = font_size)
    plt.ylabel("Temperature (K)", fontsize = font_size)
    #plt.legend(fontsize = font_size, loc="upper right")
    plt.savefig("./temp_mass/mass_vs_temp_%04d"%(count))
    #plt.savefig("mass_vs_temp_final.png")
    
    #plt.show()
    count += 1



